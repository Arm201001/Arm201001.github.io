<?php
$dirlist = getFileList(".");
?>
