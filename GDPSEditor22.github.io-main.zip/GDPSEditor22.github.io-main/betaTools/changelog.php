#editorBeta2.2.0.2#
- Fixed logo size for long screens
- Added version name
- Fixed the color of the "tools" logo, now it's random
- Fixed button position (now it's exactly in the middle)
- Embed fixed
- Optimized code and page