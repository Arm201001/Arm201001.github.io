<?php
header("Location: https://docs.google.com/spreadsheets/d/1_VPEOyhSVBZ923Ln4VU5nMI2FGwpeaSsFpJDh1Bpf7c/edit?usp=sharing");
?>